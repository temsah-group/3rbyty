// PM2 on a VPS:  npm ci && npm run build && pm2 start ecosystem.config.cjs && pm2 save
module.exports = {
  apps: [
    {
      name: '3rbyty-api',
      script: 'dist/server.js',
      node_args: '--env-file-if-exists=.env',
      instances: 1, // photos are on local disk: keep one instance
      autorestart: true,
      max_memory_restart: '400M',
      env: { NODE_ENV: 'production' },
    },
  ],
};
