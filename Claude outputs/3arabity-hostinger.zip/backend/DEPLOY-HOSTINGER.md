# رفع عربيتي على Hostinger — سايت واحد

كله شغال من **تطبيق Node.js واحد** على `3rbyty.com`:

| | الرابط |
|---|---|
| الموقع | `https://3rbyty.com` |
| لوحة الأدمن | `https://3rbyty.com/admin` |
| الـ API (للموقع والأبلكيشن) | `https://3rbyty.com/api/v1` |

الباك إند بيقدّم `front/dist` و `admin/dist` بنفسه، فمش محتاج subdomains ولا CORS بين دومينات.

## إعدادات Hostinger (Node.js Web App ← GitHub)
| الخانة | القيمة |
|---|---|
| Framework preset | Other (أو Express) |
| Branch | main |
| Node version | 22.x |
| Root directory | `./` |
| Build command | `npm run build` |
| Package manager | npm |
| Output directory | فاضي |
| Entry file / Start | `server.js` / `npm start` |

`npm run build` في أول الريبو بيعمل build للتلاتة بالترتيب.

## Environment variables (قبل أول Deploy)
انسخ القيم من `backend/.env.production.example` واملاها: `MONGO_URI` و 3 secrets و `MAIL_PASS` و `ADMIN_ACCOUNTS`.
- خلي `UPLOADS_DIR` مسار ثابت **بره** فولدر التطبيق، عشان الصور ماتتمسحش مع كل deploy.
- ولّد كل secret بالأمر ده: `node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))"`

## قبل الرفع
1. **MongoDB Atlas** ← Network Access: ضيف IP السيرفر (أو `0.0.0.0/0`).
2. اعمل إيميل `follow@3rbyty.com` من hPanel ← Emails.
3. **Google OAuth**: ضيف `https://3rbyty.com` في Authorized JavaScript origins.
4. **أبلكيشن الموبايل**: غيّر رابط الـ API فيه لـ `https://3rbyty.com/api/v1`.

## اتأكد بعد الرفع
- [ ] `https://3rbyty.com/api/v1/health` بيرد `success: true`.
- [ ] الموقع بيفتح، وعمل Refresh على `/parts` مش بيدي 404.
- [ ] `https://3rbyty.com/admin` بيفتح، والدخول بحساب `ADMIN_ACCOUNTS` شغال.
- [ ] كود الـ OTP بيوصل على الإيميل.
- [ ] رفع صورة بيشتغل والصورة بتظهر.

## تحديث بعد كده
اعمل `git push` على `main`، وبعدين Redeploy من hPanel (لو الـ auto-deploy مش شغال).
