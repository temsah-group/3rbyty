import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import express, { type Express, type RequestHandler } from 'express';

/** The repo holding backend/, front/ and admin/ (this file is 4 folders down). */
const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../../..');

export type StaticSites = { web: string | null; admin: string | null };

/** The built site and dashboard to serve, when their `index.html` exists. */
export function findStaticSites(webDir: string, adminDir: string): StaticSites {
  const pick = (configured: string, fallback: string) => {
    const dir = path.resolve(configured || fallback);
    return existsSync(path.join(dir, 'index.html')) ? dir : null;
  };
  return {
    web: pick(webDir, path.join(repoRoot, 'front', 'dist')),
    admin: pick(adminDir, path.join(repoRoot, 'admin', 'dist')),
  };
}

const staticOptions = {
  index: false,
  setHeaders: (res: express.Response, file: string) => {
    // Build files carry a hash in their name; index.html must stay fresh.
    if (file.includes(`${path.sep}assets${path.sep}`)) {
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
    } else if (file.endsWith('index.html')) {
      res.setHeader('Cache-Control', 'no-cache');
    }
  },
};

/** Single-page app: every page path (not a file, not the API) gets index.html. */
function spaFallback(dir: string, skip: (url: string) => boolean): RequestHandler {
  const index = path.join(dir, 'index.html');
  return (req, res, next) => {
    if ((req.method !== 'GET' && req.method !== 'HEAD') || skip(req.path) || path.extname(req.path)) {
      return next();
    }
    res.setHeader('Cache-Control', 'no-cache');
    res.sendFile(index);
  };
}

const isServerPath = (url: string) =>
  url === '/api' || url.startsWith('/api/') || url.startsWith('/uploads/') || url === '/sitemap.xml';

/** The dashboard under /admin, the website at /. Mounted after the API routes. */
export function mountStaticSites(app: Express, sites: StaticSites) {
  if (sites.admin) {
    app.use('/admin', express.static(sites.admin, staticOptions));
    app.use('/admin', spaFallback(sites.admin, () => false));
  }
  if (sites.web) {
    app.use(express.static(sites.web, staticOptions));
    app.use(spaFallback(sites.web, isServerPath));
  }
}
