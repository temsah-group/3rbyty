// Hostinger entry file: starts the API, which also serves front/dist and admin/dist.
import './backend/dist/server.js';
